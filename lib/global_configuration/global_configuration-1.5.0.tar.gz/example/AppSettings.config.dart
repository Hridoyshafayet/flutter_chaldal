final Map<String, String> appSettings = {
  "key1": "value1",
  "key2": "value2"
};